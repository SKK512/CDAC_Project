/*
 * vib.h
 *
 *  Created on: Nov 4, 2025
 *      Author: sunbeam
 */

#ifndef VIB_H_
#define VIB_H_

#include<stm32f4xx.h>

void vib_init(void);
uint16_t vibsenread(void);
void vib_led_on(uint8_t pin);
void vib_led_off(uint8_t pin);
void vib_led_init(uint8_t pin);

#endif /* VIB_H_ */
